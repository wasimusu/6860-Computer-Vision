function [output, blobCount] = FindComponentLabelNoBorder(image, removeOverlaps, removeBorder)

    [row, col] = size(image);

    % Read wirebond
    dilationImage = zeros(size(image)); % When a point is found, that point is dilated on this image
    prevDilatedImage = dilationImage; % Used to compare changes in dilation
    output = dilationImage; % Contains labelled circles / blobs

    se = strel('disk', 3); 

    blobCount = 0;
    blobDim = [];

    for r = 1:row
        for c = 1:col
            pixelI = image(r, c);
            pixelO = output(r, c);        
            % Only when a pixel in blank is black and and pixel in input image 
            % is white.
            % else it has already been lablled
            if (pixelI == 1 && pixelO == 0)
                dilationImage(r, c) = 1;
                while 1
                    dilationImage = imdilate(dilationImage, se);
                    dilationImage = dilationImage & image;
                    if(dilationImage == prevDilatedImage)
                        % No change is taking place and is worth breaking
                        break
                    else
                        prevDilatedImage = dilationImage;
                    end
                end
                pos = find(dilationImage==1);            
                blobCount = blobCount + 1;
                output(pos) = blobCount;
                disp(blobCount)            

                blobDim = [blobDim, length(pos)];
                % Let's find another blob
                dilationImage = zeros(size(image));            
            end
        end
    end

    if removeBorder
        % Delete Border blobs
        deleted = 0;
        for r = 1:row
            for c = 1:col
                pixel = output(r, c);
                if (pixel ~= 0 ) && (r == 1 || r == row || c == 1 || c == col)
                    pos = find(output == pixel);
                    output(pos) = 0;
                    deleted = deleted + 1;
                end
            end
        end

        % Readjust after deleting border blobs
        newCount = 1;
        for i = 1:blobCount
            pos = find(output == i);
            if isempty(pos)
                disp("Empty sequence");
            else
                output(pos) = newCount;
                newCount = newCount + 1;
            end
        end
        blobCount = blobCount - deleted;
    end

    % Remove everything that's not the median size
    if removeOverlaps
        % Find the median size of blobs that are not connected to the border
        blobDim = sort(blobDim(1:min([10, blobCount])));

        mm = median(blobDim);
        disp(mm)
        lSize = (mm*0.6);
        uSize = (mm*1.1);
        temp = zeros(size(image));

        newCount = 1;
        area = 0;
        for i = 1: blobCount
            pos = (find(output==i));
            len = length(pos);
            if (len >= lSize) && (len <= uSize)
                area = area + len;
                temp(pos) = newCount;
                newCount = newCount + 1;
            end    
        end
        blobCount = newCount;
        output = temp;
    disp(["Area : " + area / blobCount]);
    end

    output = output * (255 / blobCount);
    output = uint8(output);
    % figure; imshow(output); title('LabelledImage');

    % % Check if two images are same
    % temp = output * 255;
    % if temp ~= image
    %     disp('Image and output equal');
    %     diff = uint8(image) - uint8(temp);
    %     diff = uint8(diff);
    %     figure; imshow(diff); title('Equal Output');
    % 
    % else
    %     diff = uint8(image) - uint8(temp);
    %     diff = uint8(diff);
    %     figure; imshow(diff); title('Minor Difference');
    %     disp('Wrong algorithm');
    % end

end
