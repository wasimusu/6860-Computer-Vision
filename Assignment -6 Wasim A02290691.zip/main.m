% WASIM AKRAM KHAN -- Assignment 6
% A02290691

ball
pause;
% -----  Finish Solving Problem 1  -----%

cbir
pause;
% -----  Finish Solving Problem 2  -----%

watermark
pause;
% -----  Finish Solving Problem 2  -----%
close all